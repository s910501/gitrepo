from celery.events import EventReceiver
from kombu import Connection as BrokerConnection

connection = BrokerConnection('redis://:ehl4u9WmPrxcFpLiJxLLMwNrPxQCQCAQ@127.0.0.1:6379/0')
def on_event(event):
    print("EVENT HAPPENED: ", event)

def on_task_failed(event):
    exception = event['exception']
    print("TASK FAILED!", event, " EXCEPTION: ", exception)

while True:
   with connection as conn:
       recv = EventReceiver(conn,
                        handlers={'task-failed' : on_task_failed,
                                  'task-succeeded' : on_event,
                                  'task-sent' : on_event,
                                  'task-received' : on_event,
                                  'task-revoked' : on_event,
                                  'task-started' : on_event,
                                  # OR: '*' : on_event
                                  })
   print(recv)
   if recv:
       recv.capture(limit=None, timeout=None, wakeup=False)

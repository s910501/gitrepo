"""sshtest URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.11/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))

bastion URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.conf.urls import url, include
from django.urls import path
from django.contrib import admin
from websshapp.views import Index
from websshapp.views import SshLogPlay, SshLogList, SshTerminalMonitor, SshTerminalKill, CommandExecute, MachineList, FileEdit
from websshapp.views import CredentialCreate, CredentialList, CredentialDetailApi, QRGeneratorView, WebTerminal, GroupList
from websshapp.views import GetOpenMachine, Database, GetTables, ChangePassword, TokenList, MediaView, Upload, ServerList, RunScript
from websshapp.views import AddOperationList, ViewOperationLog, MachineDetail, SendEmail, InstallServerView, CeleryList, CeleryDetail
from saltapi.views import MissionList, MissionDetail, SaltApi
from users.views import Login
from rest_framework.documentation import include_docs_urls
from django.contrib.auth.views import LoginView,LogoutView
from django.views.static import serve
from django.conf import settings
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from rest_framework_jwt.views import obtain_jwt_token
from django.contrib.auth.views import logout
from django.urls import path

# import xadmin
# xadmin.autodiscover()
# # version模块自动注册需要版本控制的 Model
# from xadmin.plugins import xversion
# xversion.register_models()

app_name="bastion"
admin.site.site_header = '运维后台'
admin.site.index_title = '服务器管理'
admin.site.site_title = '运维后台'
# from django.conf.urls import handler400, handler403, handler404, handler500

handler400 = 'websshapp.views.my_custom_bad_request_view'
handler403 = 'websshapp.views.my_custom_permission_denied_view'
handler404 = 'websshapp.views.my_custom_page_not_found_view'
handler500 = 'websshapp.views.my_custom_error_view'
handler502 = 'websshapp.views.my_custom_error_view'

urlpatterns = [
    url(r'^$', Index.as_view(), name='index'),
    url(r'^login/$', Login.as_view(), name='login'),
    url(r'^upload/$', Upload.as_view(), name='upload'),
    url(r'^fileedit/$', FileEdit.as_view(), name='fileedit'),
    url(r'^serverlist/$', ServerList.as_view(), name='serverlist'),
    url(r'^runscript/$', RunScript.as_view(), name='runscript'),
    url(r'^addOperationList/$', AddOperationList.as_view(), name="addOperationList"),
    #url(r'^commandcallback/$', CommandCallback.as_view(), name="commandcallback"),
    url(r'^view_operationlog/$', ViewOperationLog.as_view(), name="view_operationlog"),
    url(r'^machineslist/(?P<groupname>.*)/$', MachineList.as_view(), name='machineslist'),
    url(r'^machinedetail/(?P<ipaddr>.*)/$', MachineDetail.as_view(), name='machinedetail'),
    url(r'^groupslist/$', GroupList.as_view(), name='groupslist'),
    url(r'^webterminal/(?P<ipaddr>.*)/(?P<Credential>.*)/$', WebTerminal.as_view(),name='webterminal'),
    url(r'^commandexecute/$',CommandExecute.as_view(),name='commandexecute'),
    url(r'^sshlogslist/$',SshLogList.as_view(),name='sshlogslist'),
    url(r'^sshlogplay/(?P<pk>[0-9]+)/', SshLogPlay.as_view(), name='sshlogplay'),
    url(r'^sshterminalmonitor/(?P<pk>[0-9]+)/', SshTerminalMonitor.as_view(), name='sshterminalmonitor'),
    url(r'^sshterminalkill/$',SshTerminalKill.as_view(),name='sshterminalkill'),
    url(r'^admin/', admin.site.urls),
    # url(r'^login/', obtain_jwt_token),
    # url(r'^logout/$', logout, {'next': '/'}, name='logout'),
    url(r'^changepassword/$', ChangePassword.as_view(), name="changepassword"),
    # url(r'^login/$', LoginView.as_view(template_name='admin/login.html'),name='login'),
    url(r'^logout/$',LogoutView.as_view(template_name='registration/logged_out.html'),name='logout'),
    url(r'^docs/', include_docs_urls(title="hoolai bostion")),

    url(r'^getopenmachine/', GetOpenMachine.as_view()),

    url(r'^credentialcreate/$', CredentialCreate.as_view(), name='credentialcreate'),
    url(r'^credentiallist/$', CredentialList.as_view(), name='credentiallist'),
    url(r'^credentialdetailapi/$', CredentialDetailApi.as_view(), name='credentialdetailapi'),
    url(r'^filemanager/', include('filemanager_app.urls')),
    url(r'^database/$', Database.as_view(), name="database"),
    url(r'^get_tables/(?P<mysql_id>[0-9]+)/$', GetTables.as_view(), name="get_tables"),
    url(r'^tokenlist/$',TokenList.as_view(),name='tokenlist'),
    url(r'^media/(?P<path>.*)$', MediaView.as_view(), name='media'),
    url(regex=r'^qr/(?P<user>.*)/$', view=QRGeneratorView.as_view(), name='qr'),
    # path(r'xadmin/', xadmin.site.urls),

    ## saltapi
    url(r'^missionlist/$',MissionList.as_view(),name='missionlist'),
    url(r'^missiondetail/$',MissionDetail.as_view(),name='missiondetail'),
    url(r'^saltapi/$',SaltApi.as_view(),name='saltapi'),

    ## celery
    url(r'^celerylist/$', CeleryList.as_view(), name='celerylist'),
    url(r'^celerydetail/$', CeleryDetail.as_view(), name='celerydetail'),

    ## utils
    url(r'^sendemail/$',SendEmail.as_view(),name='sendemail'),
    url(r'^installserver/$',InstallServerView.as_view(),name='installserver'),

]
# if settings.DEBUG:
#     urlpatterns += staticfiles_urlpatterns()
#     urlpatterns += [
#         url(r'^media/(?P<path>.*)$', serve, { 'document_root': settings.MEDIA_ROOT, }),
#     ]

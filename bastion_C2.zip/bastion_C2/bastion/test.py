import paramiko
import interactive
import time

ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
ssh.connect('192.168.100.29', port=22, username='root', password='hoolaigz', timeout=3)
chan = ssh.invoke_shell()
#channel=chan
#channel.send('hostname\n')
#time.sleep(3)
#output=channel.recv(2024)
#print(output)
#
##Close the connection
#ssh.close()
#print('Connection closed.')
interactive.interactive_shell(chan)

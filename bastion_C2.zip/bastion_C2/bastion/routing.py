from channels.routing import route, route_class
from bastion.consumers import webterminal, SshTerminalMonitor,CommandExecute,Celery  #导入处理函数

channel_routing = [
    #route("http.request", consumers.http_consumer), 这个表项比较特殊，他响应的是http.request，也就是说有HTTP请求时就会响应，同时urls.py里面的表单会失效

    route_class(webterminal, path=r'^/ws'),
    route_class(CommandExecute, path=r'^/execute'),
    route_class(SshTerminalMonitor, path=r'^/monitor/(?P<channel>\w+-\w+-\w+-\w+-\w+-\w+)'),
    route_class(Celery, path=r'^/celery/(?P<channel>\w+-\w+-\w+-\w+-\w+-\w+)'),

]

import json, paramiko, time, socket, os, io
import urllib.parse
import threading
from utils.utils import decrypt, encrypt
from utils import set_redis_password

from django.core.exceptions import ObjectDoesNotExist
from channels.generic.websockets import WebsocketConsumer
from django.utils.timezone import now
from websshapp.models import MachineList, CommandsSequence, MachineGroup, SshLog, Credential
from django.contrib.auth.models import User

from websshapp.interactive import interactive_shell, get_redis_instance, SshTerminalThread
from websshapp.sudoterminal import ShellHandler
from channels import Group
from django.http import HttpResponse
from channels.handler import AsgiHandler
from utils.base import get_token
from channels.handler import AsgiRequest
from websshapp.models import AuthToken, JobList
import logging
from django.db.models import Q
from utils.sshconn import http_proxy_tunnel_connect
from django.contrib.auth import get_user_model


from websshapp.tasks import run, maketemplate, installserver, initserver, hefu
User = get_user_model()

# logging.basicConfig(level=logging.DEBUG)
# LOG = logging.getLogger("xxx")
logger = logging.getLogger('send_admin_email')

class webterminal(WebsocketConsumer):
    ssh = paramiko.SSHClient()
    http_user = True
    http_user_and_session = True
    channel_session = True
    channel_session_user = True

    def connect(self, message):
        connect_text = {'accept': False,'user': None}
        message.content['method'] = 'FAKE'
        request = AsgiRequest(message)
        print(request.COOKIES)
        token = request.COOKIES.get('token', None)
        if token is not None:
            token = urllib.parse.unquote(token).strip('"')
            print(token)
            #token = urllib.unquote(token).strip('"')
            try:
                auth_token = AuthToken.objects.get(key=token)
                if auth_token.in_valid_tokens:
                    message.channel_session['user_id'] = auth_token.user_id
                    connect_text['accept'] = True
                    connect_text['user'] = auth_token.user_id
                    message.reply_channel.send({'text': json.dumps(connect_text)})
                    self.message.reply_channel.send({"text": json.dumps(['channel_name', self.message.reply_channel.name])},immediately=True)
            except AuthToken.DoesNotExist:
                print('auth_token provided was invalid.')
        else:
            logger.error('websocket webterminal login failed')
            message.reply_channel.send({'accept': False})
        return



        #self.message.reply_channel.send({"accept": True})
        ## permission auth
        #print(self.message.reply_channel.name)
        #self.message.reply_channel.send({"text": json.dumps(['channel_name', self.message.reply_channel.name])},
        #                                immediately=True)
        #print('accept')

    def disconnect(self, message):
        # close threading
        try:
            self.closessh()
            self.message.reply_channel.send({"accept": False})

            audit_log = SshLog.objects.get(user=User.objects.get(username='admin'),
                                           channel=self.message.reply_channel.name)
            audit_log.is_finished = True
            audit_log.end_time = now()
            audit_log.save()
            self.close()
        except:
            pass

    def queue(self):
        queue = get_redis_instance()
        return queue

    def closessh(self):
        # close threading
        self.queue().publish(self.message.reply_channel.name, json.dumps(['close']))

    def receive(self, text=None, bytes=None, **kwargs):
        try:
            if text:
                data = json.loads(text)
                begin_time = time.time()
                # 客户端连接处理
                if data[0] == 'ip':
                    print(data)
                    ip, width, height, credential, initcmdline = data[1], data[2], data[3], data[4], data[5]
                    self.ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                    try:
                        data = MachineList.objects.get(Q(ip=ip) | Q(internetip=ip))
                        credential = Credential.objects.get(id=int(credential), addby=self.message.user)
                        port = credential.port
                        method = credential.method
                        password = decrypt(credential.password)
                        username = credential.username
                        proxy = credential.proxy
                        proxyserverip = credential.proxyserverip
                        proxyport = credential.proxyport
                        key = credential.key
                        sock = ''
                        # username=self.message.user
                        audit_log = SshLog.objects.create(user=User.objects.get(username=self.message.user),
                                                          server=data, channel=self.message.reply_channel.name,
                                                          width=width, height=height)
                        audit_log.save()
                    except ObjectDoesNotExist:
                        self.message.reply_channel.send({"text": json.dumps(
                            ['stdout', '\033[1;3;31mConnect to server! Server ip or credential doesn\'t exist!\033[0m'])},
                                                        immediately=True)
                        self.message.reply_channel.send({"accept": False})
                    try:
                        if proxy:
                            sock = http_proxy_tunnel_connect(proxy=(proxyserverip, proxyport), target=(ip, port), timeout=30)
                    except Exception as e:
                        self.message.reply_channel.send({"text": json.dumps(
                            ['stdout','\033[1;3;31m代理服务器连接失败\033[0m'])},immediately=True)
                        self.message.reply_channel.send({"accept": False})
                    try:
                        if method == 'password' and not proxy:
                            self.ssh.connect(ip, port=port, username=username, password=password, timeout=30)
                        elif method == 'password' and proxy:
                            from bastion.asgi import channel_layer
                            redis_instance = channel_layer._connection_list[0]
                            password = redis_instance.get('OPENPASSWORD');
                            ## 无密码时获取密码，有密码时直接连接，出错时再获取密码连接
                            if not password:
                                password = set_redis_password(redis_instance)
                            try:
                                self.ssh.connect(ip,sock=sock, port=port, username=username, password=password, timeout=30)
                            except Exception as e:
                                password = set_redis_password(redis_instance)
                                self.ssh.connect(ip, sock=sock, port=port, username=username, password=password,
                                                 timeout=30)

                        else:
                            #pkey = paramiko.RSAKey.from_private_key_file(key, password=password)
                            private_key_file = io.StringIO()
                            private_key_file.write(key)
                            private_key_file.seek(0)
                            pkey = paramiko.RSAKey.from_private_key(private_key_file, password=password)
                            self.ssh.connect(ip, port=port, username=username, pkey=pkey, timeout=10)
                            #self.ssh.connect(ip, port=port, username=username, key_filename=key, timeout=10)
                    except socket.timeout:
                        self.message.reply_channel.send(
                            {"text": json.dumps(['stdout', '\033[1;3;31mConnect to server time out\033[0m'])},
                            immediately=True)
                        self.message.reply_channel.send({"accept": False})
                        return
                    except Exception as e:
                        print(e)
                        self.message.reply_channel.send(
                            {"text": json.dumps(['stdout', '\033[1;3;31mCan not connect to server\033[0m'])},
                            immediately=True)
                        self.message.reply_channel.send({"accept": False})
                        return

                    chan = self.ssh.invoke_shell(width=width, height=height, term='xterm')
                    # open a new threading to handle ssh to avoid global variable bug
                    # 从订阅的Redis取数据，发送命令线程
                    t1 = SshTerminalThread(self.message, chan, initcmdline)
                    t1.setDaemon = True
                    t1.start()

                    directory_date_time = now()
                    log_name = os.path.join('{0}-{1}-{2}'.format(directory_date_time.year, directory_date_time.month,
                                                                 directory_date_time.day),
                                            '{0}.json'.format(audit_log.log))

                    # 接收命令输出线程，向客户端websocket发送命令结果
                    t2 = threading.Thread(target=interactive_shell, args=(chan, self.message.reply_channel.name),
                                          kwargs={'log_name': log_name, 'width': width, 'height': height})
                    t2.setDaemon = True
                    t2.start()

                # 向Redis中输入数据
                # elif data[0] in ['stdin', 'stdout']:
                elif data[0] in ['stdin', 'stdout']:
                    self.queue().publish(self.message.reply_channel.name, json.loads(text)[1])
                elif data[0] == 'set_size':
                    self.queue().publish(self.message.reply_channel.name, text)
                else:
                    self.message.reply_channel.send(
                        {"text": json.dumps(['stdout', '\033[1;3;31mUnknow command found!!!!\033[0m'])},
                        immediately=True)
            elif bytes:
                self.queue().publish(self.message.reply_channel.name, json.loads(bytes)[1])
        except socket.error:
            # username=self.message.user
            audit_log = SshLog.objects.get(user=User.objects.get(username='admin'),
                                           channel=self.message.reply_channel.name)
            audit_log.is_finished = True
            audit_log.end_time = now()
            audit_log.save()
            self.closessh()
            self.close()
        except Exception:
            print(1)
            import traceback
            traceback.print_exc()
            self.closessh()
            self.close()


class CommandExecute(WebsocketConsumer):
    http_user = True
    http_user_and_session = True
    channel_session = True
    channel_session_user = True

    def connect(self, message):
        pass
        connect_text = {'accept': False,'user': None}
        message.content['method'] = 'FAKE'
        request = AsgiRequest(message)
        token = request.COOKIES.get('token', None)
        if token is not None:
            token = urllib.parse.unquote(token).strip('"')
            print(token)
            #token = urllib.unquote(token).strip('"')
            try:
                auth_token = AuthToken.objects.get(key=token)
                if auth_token.in_valid_tokens:
                    message.channel_session['user_id'] = auth_token.user_id
                    connect_text['accept'] = True
                    connect_text['user'] = auth_token.user_id
                    message.reply_channel.send({'text': json.dumps(connect_text)})
                    self.message.reply_channel.send({"text": json.dumps(['channel_name', self.message.reply_channel.name])},immediately=True)
            except AuthToken.DoesNotExist:
                print('auth_token provided was invalid.')
        else:
            logger.error('websocket CommandExecute login failed')
            message.reply_channel.send({'accept': False})
        return
#    def connect(self, message):
#        print('connect by client')
#        self.message.reply_channel.send({"accept": True})
#        # permission auth

    def disconnect(self, message):
        print('close by client!!!')
        self.message.reply_channel.send({"accept": False})
        self.close()

    def receive(self, text=None, bytes=None, **kwargs):
        try:
            if text:
                data = json.loads(text)
                if isinstance(data, list):
                    return
                if 'parameter' in data:
                    parameter = data['parameter']
                    taskname = parameter.get('taskname', None)
                    groupname = parameter.get('groupname', None)
                    ip = parameter.get('ip', None)
                    if taskname and ip and groupname:
                        server_list = [ip]
                    elif taskname and not ip and not groupname:
                        server_list = []
                        [server_list.extend(
                            [server.ip for server in MachineGroup.objects.get(name=group.name).servers.all()]) for group
                         in CommandsSequence.objects.get(name=taskname).group.all()]
                    elif taskname and groupname and not ip:
                        server_list = [server.ip for server in MachineGroup.objects.get(name=groupname).servers.all()]
                    print(CommandsSequence.objects.get(name=taskname).commands)
                    commands = json.loads(CommandsSequence.objects.get(name=taskname).commands)
                    if isinstance(commands, (str,)):
                        commands = ast.literal_eval(commands)
                    # Run commands
                    for server_ip in server_list:

                        self.message.reply_channel.send({"text": json.dumps(
                            ['stdout', '\033[1;3;33m%sExecute task on server:%s%s \033[0m' % ('='*40, server_ip, '='*40)])},
                                                        immediately=True)

                        # get server credential info
                        serverdata = MachineList.objects.get(ip=server_ip)
                        port = serverdata.credential.port
                        method = serverdata.credential.method
                        username = serverdata.credential.username
                        if method == 'password':
                            credential = serverdata.credential.password
                        else:
                            credential = serverdata.credential.key


                            # do actual job
                        ssh = ShellHandler(server_ip, username, port, method, credential,
                                           channel_name=self.message.reply_channel.name)
                        for command in commands:
                            ssh.execute(command)
                        del ssh

                else:
                    # illegal
                    self.message.reply_channel.send(
                        {"text": json.dumps(['stdout', '\033[1;3;31mIllegal parameter passed to the server!\033[0m'])},
                        immediately=True)
                    self.close()
            if bytes:
                data = json.loads(bytes)
        except Exception as e:
            import traceback
            traceback.print_exc()
            self.message.reply_channel.send({"text": json.dumps(['stdout',
                                                                 '\033[1;3;31mSome error happend, Please report it to the administrator! Error info:%s \033[0m' % (
                                                                 e)])}, immediately=True)


class SshTerminalMonitor(WebsocketConsumer):
    http_user = True
    http_user_and_session = True
    channel_session = True
    channel_session_user = True

    def connect(self, message, channel):
        pass
        connect_text = {'accept': False,'user': None}
        message.content['method'] = 'FAKE'
        request = AsgiRequest(message)
        print(request.COOKIES)
        token = request.COOKIES.get('token', None)
        if token is not None:
            token = urllib.parse.unquote(token).strip('"')
            print(token)
            #token = urllib.unquote(token).strip('"')
            try:
                auth_token = AuthToken.objects.get(key=token)
                if auth_token.in_valid_tokens:
                    message.channel_session['user_id'] = auth_token.user_id
                    connect_text['accept'] = True
                    connect_text['user'] = auth_token.user_id
                    message.reply_channel.send({'text': json.dumps(connect_text)})
                    Group(channel).add(self.message.reply_channel.name)
            except AuthToken.DoesNotExist:
                print('auth_token provided was invalid.')
        else:
            logger.error('websocket SshTerminalMonitor login failed')
            message.reply_channel.send({'accept': False})
        return

    #def connect(self, message, channel):
    #    self.message.reply_channel.send({"accept": True})
    #    print('monitor connect')
    #    # permission auth
    #    print(channel,self.message.reply_channel.name)
    #    Group(channel).add(self.message.reply_channel.name)

    def disconnect(self, message, channel):
        Group(channel).discard(self.message.reply_channel.name)
        self.message.reply_channel.send({"accept": False})
        self.close()
        print('close')

    def receive(self, text=None, bytes=None, **kwargs):
        pass


class Celery(WebsocketConsumer):
    http_user = True
    http_user_and_session = True
    channel_session = True
    channel_session_user = True
    USERNAME = ''

    def connect(self, message, channel):
        connect_text = {'accept': False,'user': None}
        message.content['method'] = 'FAKE'
        request = AsgiRequest(message)
        token = request.COOKIES.get('token', None)
        USERNAME = request.COOKIES.get('username', None)
        if token is not None:
            token = urllib.parse.unquote(token).strip('"')
            #token = urllib.unquote(token).strip('"')
            try:
                auth_token = AuthToken.objects.get(key=token)
                if auth_token.in_valid_tokens:
                    message.channel_session['user_id'] = auth_token.user_id
                    connect_text['accept'] = True
                    connect_text['user'] = auth_token.user_id
                    message.reply_channel.send({'text': json.dumps(connect_text)})
                    Group(channel).add(self.message.reply_channel.name)
            except AuthToken.DoesNotExist:
                print('auth_token provided was invalid.')
        else:
            logger.error('websocket Celery login failed')
            message.reply_channel.send({'accept': False})
        return

    def disconnect(self, message, channel):
        Group(channel).discard(self.message.reply_channel.name)
        self.message.reply_channel.send({"accept": False})
        self.close()
        print('close')

    def send_tasks(self,taskname,runfunction,reply_channel,**kwargs):
        job = JobList(name=taskname,status="started",)
        job.save()
        task = runfunction.apply_async(args=[job.id,reply_channel],kwargs=kwargs)
        Group('celery-04f2e591-a84e-4b5d-a029-f08160efbed0').send({
            "text": json.dumps({
                "action": "started",
                "job_id": job.id,
                "job_name": job.name,
                "job_start_time": job.create_datetime.strftime("%m/%d/%Y %I:%M:%S %p"),
                "celery_id": task.id,
            })
        })
        job.celery_id=task.id
        job.save()

    def receive(self, text=None, bytes=None, **kwargs):
        if json.loads(text)[0] == 'liststartjobs':
            startjobs = JobList.objects.filter(Q(status="started")|Q(status="failed"), confirm=False)
            for job in startjobs:
                Group('celery-04f2e591-a84e-4b5d-a029-f08160efbed0').send({
                    "text": json.dumps({
                        "action": job.status,
                        "job_id": job.id,
                        "job_name": job.name,
                        "job_start_time": job.create_datetime.strftime("%m/%d/%Y %I:%M:%S %p"),
                        "celery_id": job.celery_id,
                    })
                })
        elif json.loads(text)[0] == 'maketemplate':
            reply_channel = self.message.reply_channel.name
            self.send_tasks('生成装服模板文件',maketemplate,reply_channel)
        elif json.loads(text)[0] == 'installserver':
            reply_channel = self.message.reply_channel.name
            kw = json.loads(text)[1]
            self.send_tasks('安装新服',installserver,reply_channel,**kw)
        elif json.loads(text)[0] == 'initserver':
            reply_channel = self.message.reply_channel.name
            kw = json.loads(text)[1]
            self.send_tasks('机器初始化', initserver, reply_channel, **kw)
        elif json.loads(text)[0] == 'hefu':
            username = self.USERNAME
            reply_channel = self.message.reply_channel.name
            kw = json.loads(text)[1]
            kw['username'] = username
            self.send_tasks('合服:'+str(kw['operid']), hefu, reply_channel, **kw)
        else:
            self.message.reply_channel.send({"text": json.dumps(['stderr', '未知选择！'])})
        #job = JobList(name='make_template',status="started",)
        #job.save()
        #from websshapp.tasks import run
        #print(text)
        #reply_channel = self.message.reply_channel.name
        ##self.message.reply_channel.send({"text": json.dumps(['stdout','6666'])})
        #task = run.delay('uptime',job.id,reply_channel)
        #print(job.create_datetime.strftime("%m/%d/%Y %I:%M:%S %p"))
        #Group('celery-04f2e591-a84e-4b5d-a029-f08160efbed0').send({
        #    "text": json.dumps({
        #        "action": "started",
        #        "job_id": job.id,
        #        "job_name": job.name,
        #        "job_start_time": job.create_datetime.strftime("%m/%d/%Y %I:%M:%S %p"),
        #    })
        #})
        #job.celery_id=task.id
        #job.save()
        #runscripttype(data,reply_channel)

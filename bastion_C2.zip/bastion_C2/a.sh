cat /tmp/a.txt | while read line;do
    ip=`echo $line | awk '{print $1}'`
    db=`echo $line | awk '{print $4}'`
    dbip=`echo $db | awk -F: '{print $1}'`
    dbport=`echo $db | awk -F: '{print $2}'`
    dbname=`echo $line | awk '{print $5}'`
    echo "$dbip,$dbport,$dbname========================="
    mysql -uroot -h$dbip -P$dbport -phoolai12 $dbname -e "select * from globaluser where account='B9DAF4AADD1978AC47F3A175DA21DDF6';"
    [ $? -eq 0 ] && echo 'done'
done;

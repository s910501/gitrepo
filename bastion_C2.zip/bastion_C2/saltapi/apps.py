from django.apps import AppConfig


class SaltapiConfig(AppConfig):
    name = 'saltapi'

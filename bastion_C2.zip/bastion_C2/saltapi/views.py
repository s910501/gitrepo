import json, re
import paramiko
from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect
from django.http import JsonResponse
from guardian.mixins import PermissionRequiredMixin
from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.generic import View
from websshapp.models import MachineList as MachineListModel
from bastion.settings import SALTMASTER
import salt.runner

# Create your views here.
opts = salt.config.master_config('/etc/salt/master')
runner = salt.runner.RunnerClient(opts)
local = salt.client.LocalClient()


import salt.runner
runner = salt.runner.RunnerClient(opts)

import salt.config
import salt.wheel
wheel = salt.wheel.WheelClient(opts)

from salt.client.ssh.shell import Shell


class MissionList(LoginRequiredMixin, View):
    def get(self, request):
        #opts = salt.config.master_config('/etc/salt/master')
        #runner = salt.runner.RunnerClient(opts)
        jobs = runner.cmd('jobs.list_jobs', [])
        print(jobs)
        job = dict((key,value) for key, value in jobs.items() if not re.match('runner\.jobs\.list_job',value['Function']))
        return render(request,'missionlist.html', {"jobs": job})


class MissionDetail(LoginRequiredMixin, View):
    def get(self, request):
        id = request.GET.get('id','')
        result = runner.cmd('jobs.list_job', [id])
        print(result['Result'])
        return JsonResponse(result)


class SaltApi(LoginRequiredMixin, View):
    def get(self, request):
        machinelist = MachineListModel.objects.all()
        return render(request, 'saltapi.html', locals())
    def post(self, request):
        local = salt.client.LocalClient()
        groupCheckbox = json.loads(request.POST.get('checkedArray'))
        machinelist = MachineListModel.objects.all()
        bgexecute = request.GET.get('bg')
        apitype = request.POST.get('apitype')
        module = request.POST.get('param1')
        param2 = request.POST.get('param2')
        allmodule = module.split('%%%')
        allparam = param2.split('%%%')
        allparam = [ [x] for x in allparam ]
        if param2 == '':
            allparam=[[]]
        print(allmodule, allparam, bgexecute, apitype)
        allhosts = []
        allips = []
        for id in groupCheckbox:
            machine = MachineListModel.objects.get(id=id)
            allhosts.append(machine.hostname)
            allips.append([machine.ip, machine.initpassword, machine.sshport, machine.hostname])
        if apitype == 'RunnerClient':
            result = runner.cmd(module, [param2])
            print(result)
            return JsonResponse(result)
        elif apitype == 'WheelClient':
            wheel = salt.wheel.WheelClient(opts)
            try:
                if param2 == '':
                    result = wheel.cmd(module)
                elif re.match('.*_dict', module):
                    jparam2 = json.loads(param2)
                    result = wheel.cmd(module, jparam2)
                else:
                    result = wheel.cmd(module, [param2])
            except Exception as e:
                return HttpResponse(e)
            return JsonResponse(result)
            # if allparam == [[]]:
            #     result = wheel.cmd(module)
            # else:
            #     result = wheel.cmd(module, allparam)
            # return JsonResponse(result)
        elif apitype == 'SSHClient':
            result =[]
            if len(allips) == 0:
                return JsonResponse({'msg': 'IP地址为空'})
            for info in allips:
                shell = Shell(host=info[0], user='root', port=info[2], passwd=info[1], opts=opts, timeout=120)
                if module == '机器初始化':
                    res = shell.send('/data/salt/base/rsync/files/script/machine_init.sh', '/root/')
                    hostname=info[0]
                    username='root'
                    password=info[1]
                    ssh = paramiko.SSHClient()
                    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                    ssh.connect(hostname=hostname, username=username, password = password, port=info[2])

                    transport = ssh.get_transport()
                    channel = transport.open_session()
                    #channel.exec_command('sh test.sh ' + SALTMASTER + ' ' + info[3] + ' &')
                    #channel.exec_command('sh machine_init.sh ' + SALTMASTER + ' ' + info[3] + ' &')

                    #stdin, stdout, stderr = ssh.exec_command('nohup sleep 20 &')
                    #print(stdout.read())
                    ##print(stdin.read())
                    #print(stderr.read())
                    #ssh.close()
                    ##result.append({info[0]: res})
                    if bgexecute:
                    #    print('bg')
                        res = shell.exec_cmd('sh machine_init.sh ' + SALTMASTER + ' ' + info[3] + ' &')
                        print(res)
                    else:
                        res = shell.exec_cmd('sh machine_init.sh ' + SALTMASTER + ' ' + info[3])
                    result.append({info[0]: res})
                else:
                    res = shell.exec_cmd(module)
                    result.append({info[0]: res})
            print('SSHClient')
            return JsonResponse({'msg': result})
        else:
            if bgexecute:
                result = local.run_job(allhosts, allmodule, allparam, tgt_type='list')
                result = {'jid': result}
            else:
                print(1)
                result = local.cmd(allhosts, allmodule, allparam, tgt_type='list', timeout=120)
                print(2)
            return JsonResponse(result)

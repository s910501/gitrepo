#!/bin/sh
temp_path=$(dirname "$0")
cd $temp_path
real_path=$(pwd)

start(){
    nohup daphne -b 127.0.0.1 -p 8051 bastion.asgi:channel_layer > $real_path/logs/daphne.log 2>&1 &
    nohup uwsgi --socket 127.0.0.1:8050 --module=bastion.wsgi:application --vacuum --processes=5 --harakiri=120 --no-orphans --master --max-requests=1000 --lazy-apps > $real_path/logs/uwsgi.log 2>&1 &
    nohup python manage.py runworker --only-channels websocket.* > $real_path/logs/runworker.log 2>&1 &
}

stop(){
    killall -9 daphne
    killall -9 uwsgi
    killall -9 python
}

case $1 in
        start)
                start
                        ;;
        stop)
                stop
                        ;;
        restart)
                stop
                sleep 3
                start
                        ;;
        *)
                echo "usage : sh $0 {start|stop|restart}"
esac


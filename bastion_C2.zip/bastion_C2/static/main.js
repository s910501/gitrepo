var term,
    protocol,
    socketURL,
    socket,
    pid,
    charWidth,
    ws,
    view_fullscreen = false,
    charHeight;

var terminalContainer = document.getElementById('terminal-container'),
    // actionElements = {
    //     findNext: document.querySelector('#find-next'),
    //     findPrevious: document.querySelector('#find-previous')
    // },
    optionElements = {
        cursorBlink: document.querySelector('#option-cursor-blink'),
        cursorStyle: document.querySelector('#option-cursor-style'),
        scrollback: document.querySelector('#option-scrollback'),
        tabstopwidth: document.querySelector('#option-tabstopwidth')
    },
    colsElement = document.getElementById('cols'),
    rowsElement = document.getElementById('rows');

// 全屏Js
$('#exit-view-fullscreen').hide();
$('.view-fullscreen').click(function () {
    view_fullscreen = !view_fullscreen;
    //term.toggleFullscreen(view_fullscreen);
    //$('#exit-view-fullscreen').toggle();
    console.log(document.body.clientWidth,document.body.clientHeight);
    if (view_fullscreen == true) {
        console.log(document.body.clientWidth,document.body.clientHeight);
        // term.resize(document.body.clientWidth-100,document.body.clientHeight)
        // var cols = Math.ceil(document.body.clientWidth/10),
        //     rows = Math.ceil(document.body.clientHeight/9);
        // ws.send(JSON.stringify(["set_size", cols, rows]));
    } else {
        //setTerminalSize()
    }
});

// function getCookie(cookieName) {
//     var cookieString = document.cookie;
//     var start = cookieString.indexOf(cookieName + '=');
//     // 加上等号的原因是避免在某些 Cookie 的值里有
//     // 与 cookieName 一样的字符串。
//     if (start == -1) // 找不到
//         return null;
//     start += cookieName.length + 1;
//     var end = cookieString.indexOf(';', start);
//     if (end == -1) return unescape(cookieString.substring(start));
//     return unescape(cookieString.substring(start, end));
// }

function setTerminalSize() {
    var cols = parseInt(colsElement.value, 10),
        rows = parseInt(rowsElement.value, 10);
    term.resize(cols, rows);
    ws.send(JSON.stringify(["set_size", cols, rows]));
}

colsElement.addEventListener('change', setTerminalSize);
rowsElement.addEventListener('change', setTerminalSize);

optionElements.cursorBlink.addEventListener('change', function () {
    term.setOption('cursorBlink', optionElements.cursorBlink.checked);
});
optionElements.cursorStyle.addEventListener('change', function () {
    term.setOption('cursorStyle', optionElements.cursorStyle.value);
});
optionElements.scrollback.addEventListener('change', function () {
    term.setOption('scrollback', parseInt(optionElements.scrollback.value, 10));
});
optionElements.tabstopwidth.addEventListener('change', function () {
    term.setOption('tabStopWidth', parseInt(optionElements.tabstopwidth.value, 10));
});

terminalContainer.style.height=String(window.innerHeight-60 )+'px';
terminalContainer.style.width=String(window.innerWidth)+'px';
optionElements.cursorBlink.checked=true;
function make_terminal(element, size, ws_url, ip, credential,initcmdline) {
    term = new Terminal({
        screenKeys: true,
        useStyle: true,
        scrollback: 3000,
        tabStopWidth: 4,
        cursorBlink: true  // Blink the terminal's cursor
    });
    term.open(element, false);
    ws = new WebSocket(ws_url);

    ws.onopen = function (event) {
        //set terminal width and height
        term.fit();
        term.getOption("geometry");
        // console.log(term.cols, term.rows,777);
        ws.send(JSON.stringify(["ip", ip, term.cols, term.rows, credential,initcmdline]));
        colsElement.value = term.cols;
        rowsElement.value = term.rows;
        // term输入数据时的行为
        term.on('data', function (data) {
            ws.send(JSON.stringify(['stdin', data]));
        });

        // term标题
        term.on('title', function (title) {
            document.title = title;
        });
        ws.send(JSON.stringify(['stdin', 'ls\r\n']));
        //term.toggleFullscreen(true);
        ws.onmessage = function (event) {
            console.log(event);
            json_msg = JSON.parse(event.data);
            switch (json_msg[0]) {
                // term 输入
                case "stdout":
                    term.write(json_msg[1]);
                    break;
                case "disconnect":
                    term.write("\r\n\r\n[Finished...]\r\n");
                    break;
                case "channel_name":
                    <!--console.log(json_msg[1]);-->
                    var channel_name_attribute = document.createAttribute('channel_name');
                    channel_name_attribute.value = json_msg[1];
                    element.setAttributeNode(channel_name_attribute);
                    break;
            }
        };

    };
    return {socket: ws, term: term};
}


//var ws_scheme = window.location.protocol == "https:" ? "wss" : "ws";
//var ws_path = ws_scheme + '://' + window.location.host + '/ws/';
//make_terminal(document.getElementById('terminal-container'), {rows: 20, cols: 170}, ws_path, '185.122.59.8');

//当浏览器窗口大小改变时，设置显示内容的高度
window.onresize=function() {
    terminalContainer.style.height = String(window.innerHeight - 60) + 'px';
    terminalContainer.style.width = String(window.innerWidth) + 'px';
    term.fit();
    term.getOption("geometry");
    // term.resize(term.cols, term.rows);
    ws.send(JSON.stringify(["set_size", term.cols, term.rows]));
}

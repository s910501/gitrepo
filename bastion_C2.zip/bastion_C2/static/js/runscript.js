$(document).ready(function(){
    $('#output').hide();
    $('#outputhide').click(function(){
        $('#output').hide();
    })
    $(':input').labelauty();
    $('#addOperationList').click(function() {
        if ( checkSubmit() == false ){
            return false;
        };
        $('form[id=serverlistform]').attr('action','/addOperationList/');
        $('form[id=serverlistform]').submit();
    });
    $('#showoperationame').click(function(){
        $('.operationname').toggle();
    });
    $('#showparm1').click(function(){
        $('.operation_parm1').toggle();
    });
    $('.progress-striped').hide();

    // 显示操作内容
    $('.operationLabel').click(function(){
        //operid = $(this).parents("tr").find("td").eq(0).text();
        operid = $(this).attr('id');
        oper_time = $(this).attr("data-original-title");
        console.log(oper_time);
        $.ajax({
                cache: true,
                type: "POST",
                url:'/view_operationlog/',
                data:{operid:operid,oper_time:oper_time},
                error: function(request) {
                    alert("错误!!!!");
                },
                success: function(data) {
                     $('#output').show();
                     var formattedData = JSON.stringify(data, null, '\t');
                     $('#command_result').text(formattedData);
                     $('pre code').each(function(i, block) {
                         hljs.highlightBlock(block);
                     });
                     console.log($('.hljs-literal').eq(1).text());
                     $('.hljs-literal').each(function(){
                         if ($(this).text() == 'true' ){
                             console.log(11);
                         } else {
                             $(this).css('background-color','red').css('color','white')
                             $(this).animate({fontSize:"2em"},"slow");
                         }
                     })
                }
        });
    });
    // 操作提示标签内容替换
    $('option').each(function(){
        var optionvar = $(this).val()
        var optiontext = $(this).text()
        $('.operationLabel').each(function(){
            if ( optionvar == $(this).text() ){
                $(this).text(optiontext);
            }
            //console.log($(this).text());
        });
         
        //$(this).val()
    });
    //$(function () { $("[data-toggle='tooltip']").tooltip(); });
});
function CheckSelect(thisform){
    // 遍历 form  
    for ( var i = 0; i < thisform.elements.length; i++)
    {
      console.log(i);
      // 提取控件  
      var checkbox = thisform.elements[i];
      // 检查是否是指定的控件  
      if (checkbox.name === "groupCheckbox" && checkbox.type === "checkbox" && checkbox.checked === false)
      {
        // 正选  
        checkbox.checked = true;
      }
      else if (checkbox.name === "groupCheckbox" && checkbox.type === "checkbox" && checkbox.checked === true)
      {
        // 反选  
        checkbox.checked = false;
      }
    }
};
function SelectRange(thisform){
     var servername_start = $('option:selected','#servername_start').index() + 10
     var servername_stop = $('option:selected','#servername_stop').index() + 10
     for ( var i = servername_start; i <= servername_stop; i++)
     {
       var checkbox = thisform.elements[i];
       checkbox.checked = true;
     }
}
function firstwar(thisform){
     var serverids=["4","22","27","47","79","230","321","427","570","612","50001","50002","50005","100001","100002","100201"]
     for (var i=0; i < serverids.length; i++){
         //console.log("input:checkbox[value="+ serverids[i] +"]");
         //使用prop方法解决取消选择后不生效的问题
         $("input:checkbox[value="+ serverids[i] +"]").prop('checked','true');
     }
}
function uncheckAll() {
     $("input[name=groupCheckbox]").attr("checked", false);
}
function checkSubmit() {
    var any_checked = false;
    $(":checkbox").each(function(){
        if(this.checked == true){
            any_checked = true;
            //退出each循环
            return false;
        }
    });
    if(any_checked == false){
        alert('没有选择服务器!');
        return false;
    }
}




$(document).ready(function(){
    // 获取opentoken
    $('#opentoken').click( function () {
        $.ajax({
             type: "get",
             url: "/get_token",
             async: false,
             success: function (data) {
                 var clipboard = new Clipboard('#opentoken', {
                     text: function() {
                         return data;
                     }
                 });
                 clipboard.on('success', function(e) {
                     $('#opentoken_txt').text(data);
                     $('#opentoken_helptxt').text('秘钥已复制:(请勿频繁获取)');
                 });

                 clipboard.on('error', function(e) {
                     alert("复制出错");
                 });
             }
        });
    });
});

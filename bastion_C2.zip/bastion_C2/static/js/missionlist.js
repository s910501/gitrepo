$(document).ready(function() {
  $('#missionlist').dataTable( {
        "order": [[ 0,"desc" ]],
        "lengthMenu": [[-1], [ "All"]],
        "dom": 'rt',
        "language": {
            "sProcessing":"处理中...",
            "sLengthMenu":"显示_MENU_项结果",
            "sZeroRecords":"没有匹配结果",
            "sInfo":"显示第_START_至_END_项结果，共_TOTAL_项",
            "sInfoEmpty":"显示第0至0项结果，共0项",
            "sInfoFiltered":"(由_MAX_项结果过滤)",
            "sInfoPostFix":"",
            "sSearch":"搜索:",
            "sUrl":"",
            "sEmptyTable":"表中数据为空",
            "sLoadingRecords":"载入中...",
            "sInfoThousands":",",
            "oPaginate":{
                "sFirst":"首页",
                "sPrevious":"上页",
                "sNext":"下页",
                "sLast":"末页"
            },
            "oAria":{
                "sSortAscending":":以升序排列此列","sSortDescending":":以降序排列此列"
            },
        }

  });
  $(".exec_result").click(function(){
      $.get("/ansible_api/exec_result/"+$(this).text(),function(data){
         $("#exec_modal").modal();
         $("#exec_result").html(data.replace(/\n/g,'<br>'));
         console.log(data.split('\n'));
      })
  });
});


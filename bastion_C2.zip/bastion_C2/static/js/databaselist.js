$(document).ready(function() {
$("#databases").change(function(data){
    dbname=$("#databases option:selected").val()
    mysql_exec(mysql_id,"show tables",dbname)
    console.log($("#databases option:selected").val());
})
$.get("/get_tables/1/",function(data,status){
    $.each(data['msg'],function(i,item){
        $('#cmdline').editableSelect('add', function () {
            $(this).text(item);
        });
    })

})
function mysql_exec(mysql_id,cmdline,select_db){
    // 表格数据源
    var ajax_data = [];
    // 表头数据
    var columns = []
    $.post("/get_tables/"+mysql_id+"/",{"cmdline":cmdline,"db":select_db},function(data,status){
        $("#mysql_result").append(data);
        $("#mysql_result").append("=================================================================================================================\n");
        mysql_data = data.split('\n');
        $("#mysql_head").text("");
        for (index in mysql_data) {
            //$("#mysql_body").append("<tr></tr>")
            data = mysql_data[index].split("\t");
            if (data[0] == ""){
                continue;
            }
            if (index == 0){
                for (dex in data){
                     columns.push({"title":data[dex]})
                     $("#mysql_head").append("<th>" + data[dex]  +"</th>");
                }
            }
            else{
                ajax_data.push(data);
            }
        }
        if ( columns.length == 0 ){
            columns.push({"title": cmdline});
            ajax_data.push(["没有查找到数据"]);
        }
        var mysql_table = $('#mysql_table').DataTable();
        mysql_table.destroy();
        $('#mysql_table').empty();
        var mysql_table = $('#mysql_table').DataTable({
           "lengthMenu": [[10,20,50,100,-1], [ "10","20","50","100","All"]],
           "data": ajax_data,
           "columns": columns,
           "destroy": true,
           "scrollX": true,
           "ordering": true,
           "order": [],
           "language": {
               "sProcessing":"处理中...",
               "sLengthMenu":"显示_MENU_项结果",
               "sZeroRecords":"没有匹配结果",
               "sInfo":"显示第_START_至_END_项结果，共_TOTAL_项",
               "sInfoEmpty":"显示第0至0项结果，共0项",
               "sInfoFiltered":"(由_MAX_项结果过滤)",
               "sInfoPostFix":"",
               "sSearch":"搜索:",
               "sUrl":"",
               "sEmptyTable":"表中数据为空",
               "sLoadingRecords":"载入中...",
               "sInfoThousands":",",
               "oPaginate":{
                   "sFirst":"首页",
                   "sPrevious":"上页",
                   "sNext":"下页",
                   "sLast":"末页"
               },
               "oAria":{
                   "sSortAscending":":以升序排列此列","sSortDescending":":以降序排列此列"
               },
           },
        });
    });
}
var databaselist = $('#databaselist').DataTable( {
    "paging": true,
    "lengthChange": true,
    "searching": true,
    "ordering": false,
    "info": true,
    "iDisplayLength": 30,
    "autoWidth": true,
    //"order": [[ 0,"desc" ]],
    "lengthMenu": [[10,20,50,100,-1], [ "10","20","50","100","All"]],
    "language": {
        "sProcessing":"处理中...",
        "sLengthMenu":"显示_MENU_项结果",
        "sZeroRecords":"没有匹配结果",
        "sInfo":"显示第_START_至_END_项结果，共_TOTAL_项",
        "sInfoEmpty":"显示第0至0项结果，共0项",
        "sInfoFiltered":"(由_MAX_项结果过滤)",
        "sInfoPostFix":"",
        "sSearch":"搜索:",
        "sUrl":"",
        "sEmptyTable":"表中数据为空",
        "sLoadingRecords":"载入中...",
        "sInfoThousands":",",
        "oPaginate":{
            "sFirst":"首页",
            "sPrevious":"上页",
            "sNext":"下页",
            "sLast":"末页"
        },
        "oAria":{
            "sSortAscending":":以升序排列此列","sSortDescending":":以降序排列此列"
        }
    }
});
  $("#mysql_result").hide();
  $("#show_mysql_result").click(function(){
      $("#mysql_result").toggle();
  });
  $('.mysql').click(function(){
      mysql_id = $(this).parent().parent().children("td").eq(0).text();
      mysql_ip = $(this).parent().parent().children("td").eq(1).text();
      mysql_port = $(this).parent().parent().children("td").eq(2).text();
      mysql_database = $(this).parent().parent().children("td").eq(3).text();
      $('#mysql_ip').text(mysql_ip);
      $('#mysql_port').text(mysql_port);
      $('#mysql_database').text(mysql_database);
      $('#mysql').modal();
      $.post("/get_tables/"+mysql_id+"/",{"cmdline":'show databases',"db":'information_schema'},function(data,status){
          databases = data.split("\n");
          databases.splice(0,1)
          $("#databases").text('')
          for ( x in databases){
              $("#databases").append('<option value="' + databases[x] + '">' + databases[x] + '</option>');
          }
      });
      mysql_exec(mysql_id,"show databases","information_schema");
  });
  $("form").submit(function(e){
//    // 表格数据源
//    var ajax_data = [];
//    // 表头数据
//    var columns = []
    e.preventDefault();
    select_db = $("#databases option:selected").text();
    cmdline = $("#cmdline").val();
    mysql_exec(mysql_id,cmdline,select_db)
    //$.post("get_tables/"+mysql_id+"/",{"cmdline":cmdline,"db":select_db},function(data,status){
    //    $("#mysql_result").append(data);
    //    mysql_data = data.split('\n');
    //    $("#mysql_head").text("");
    //    for (index in mysql_data) {
    //        //$("#mysql_body").append("<tr></tr>")
    //        data = mysql_data[index].split("\t");
    //        if (data[0] == ""){
    //            continue;
    //        }
    //        if (index == 0){
    //            for (dex in data){
    //                 columns.push({"title":data[dex]})
    //                 $("#mysql_head").append("<th>" + data[dex]  +"</th>");
    //            }
    //        }
    //        else{
    //            ajax_data.push(data);
    //        }
    //    }
    //    if ( columns.length == 0 ){
    //        columns.push({"title": cmdline});
    //        ajax_data.push(["没有查找到数据"]);
    //    }
    //    var mysql_table = $('#mysql_table').DataTable();
    //    mysql_table.destroy();
    //    $('#mysql_table').empty()
    //    var mysql_table = $('#mysql_table').DataTable({
    //       "lengthMenu": [[10,20,50,100,-1], [ "10","20","50","100","All"]],
    //       "data": ajax_data,
    //       "columns": columns,
    //       "destroy": true,
    //       "scrollX": true,
    //       "language": {
    //           "sProcessing":"处理中...",
    //           "sLengthMenu":"显示_MENU_项结果",
    //           "sZeroRecords":"没有匹配结果",
    //           "sInfo":"显示第_START_至_END_项结果，共_TOTAL_项",
    //           "sInfoEmpty":"显示第0至0项结果，共0项",
    //           "sInfoFiltered":"(由_MAX_项结果过滤)",
    //           "sInfoPostFix":"",
    //           "sSearch":"搜索:",
    //           "sUrl":"",
    //           "sEmptyTable":"表中数据为空",
    //           "sLoadingRecords":"载入中...",
    //           "sInfoThousands":",",
    //           "oPaginate":{
    //               "sFirst":"首页",
    //               "sPrevious":"上页",
    //               "sNext":"下页",
    //               "sLast":"末页"
    //           },
    //           "oAria":{
    //               "sSortAscending":":以升序排列此列","sSortDescending":":以降序排列此列"
    //           },
    //       },

    //    });
    //});
  });

});

function PostAjax(url, checkedArray){
        $.ajax({
            type: "POST",
            url:url,
            data:{checkedArray:JSON.stringify(checkedArray), param1:param1, param2:param2, apitype:apitype},// 你的formid
            //async: false,
            error: function(request) {
                alert("Connection error");
            },
            success: function(data) {
                //$('#command_result').html(unescape(data.replace(/\\u/g, "%u")));
                $('.progress-striped').hide();
                $('#output').show();
                 var formattedData = JSON.stringify(data, null, '\t');
                 $('#command_result').text(formattedData);
                 $('pre code').each(function(i, block) {
                     hljs.highlightBlock(block);
                 });
            }
        });
}

$(document).ready(function(){
    //$('#output').hide();
    $('#outputhide').click(function(){
        $('#output').hide();
    })
    $(':input').labelauty();
    $("#execute").click(function(){
        param1 = $('#param1').val();
        param2 = $('#param2').val();
        apitype = $('#apitype').val();
        if ( checkSubmit() == false){
            return false;
        }
        $('.progress-striped').show()
        var checkedArray = new Array();
        $('[name=groupCheckbox]:checkbox:checked').each(function() {
            checkedArray.push($(this).val());
        });
        PostAjax('/saltapi/', checkedArray)
    });
    $('#showoperationame').click(function(){
        $('.operationname').toggle();
    });
    $('#showparm1').click(function(){
        $('#operation_parm1').toggle();
    });
    $('.progress-striped').hide();
});

function CheckSelect(thisform){
    // 遍历 form  
    for ( var i = 0; i < thisform.elements.length; i++)
    {
      console.log(i);
      // 提取控件  
      var checkbox = thisform.elements[i];
      // 检查是否是指定的控件  
      if (checkbox.name === "groupCheckbox" && checkbox.type === "checkbox" && checkbox.checked === false)
      {
        // 正选  
        checkbox.checked = true;
      }
      else if (checkbox.name === "groupCheckbox" && checkbox.type === "checkbox" && checkbox.checked === true)
      {
        // 反选  
        checkbox.checked = false;
      }
    }
};
function SelectRange(thisform){
     var servername_start = $('option:selected','#servername_start').index() + 8
     var servername_stop = $('option:selected','#servername_stop').index() + 8
     for ( var i = servername_start; i <= servername_stop; i++)
     {
       var checkbox = thisform.elements[i];
       checkbox.checked = true;
     }
}
function uncheckAll() {
     $("input[name=groupCheckbox]").attr("checked", false);
}
function checkSubmit() {
    var any_checked = false;
    $(":checkbox").each(function(){
        if(this.checked == true){
            any_checked = true;
            //退出each循环
            return false;
        }
    });
    if(any_checked == false){
        alert('没有选择服务器!');
        return false;
    }
}




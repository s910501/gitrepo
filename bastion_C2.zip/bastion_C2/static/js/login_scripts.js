jQuery(document).ready(function() {
	
    /*
        Fullscreen background
    */
    $.backstretch([
                    "/static/img/2.jpg"
	              , "/static/img/3.jpg"
	              , "/static/img/1.jpg"
	             ], {duration: 3000, fade: 750});
    
    /*
        Form validation
    */
    $('.login-form input[type="text"], .login-form input[type="password"], .login-form textarea').on('focus', function() {
    	$(this).removeClass('input-error');
    });
    
    $('.login-form').on('submit', function(e) {
    	
    	$(this).find('input[type="text"], input[type="password"], textarea').each(function(){
    		if( $(this).val() == "" ) {
    			e.preventDefault();
    			$(this).addClass('input-error');
    		}
    		else {
    			$(this).removeClass('input-error');
    		}
    	});
    	
    });
    $("#id_auth-username").attr("placeholder","请输入用户名");
    $("#id_auth-password").attr("placeholder","请输入密码");
    $("#id_token-otp_token").attr("placeholder","请输入手机验证码");
    
    
});

// csrf ajax设置
$(document).ajaxSend(function(event, xhr, settings) {
    function getCookie(name) {
        var cookieValue = null;
        if (document.cookie && document.cookie != '') {
            var cookies = document.cookie.split(';');
            for (var i = 0; i < cookies.length; i++) {
                var cookie = jQuery.trim(cookies[i]);
                // Does this cookie string begin with the name we want?
                if (cookie.substring(0, name.length + 1) == (name + '=')) {
                    cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                    break;
                }
            }
        }
        return cookieValue;
    }
    function sameOrigin(url) {
        // url could be relative or scheme relative or absolute
        var host = document.location.host; // host + port
        var protocol = document.location.protocol;
        var sr_origin = '//' + host;
        var origin = protocol + sr_origin;
        // Allow absolute or scheme relative URLs to same origin
        return (url == origin || url.slice(0, origin.length + 1) == origin + '/') ||
            (url == sr_origin || url.slice(0, sr_origin.length + 1) == sr_origin + '/') ||
            // or any other URL that isn't scheme relative or absolute i.e relative.
            !(/^(\/\/|http:|https:).*/.test(url));
    }
    function safeMethod(method) {
        return (/^(GET|HEAD|OPTIONS|TRACE)$/.test(method));
    }

    if (!safeMethod(settings.type) && sameOrigin(settings.url)) {
        xhr.setRequestHeader("X-CSRFToken", getCookie('csrftoken'));
    }
});

$(document).ready(function(){
    // Setup - add a text input to each footer cell表格角搜索
    $('#serverlist tfoot th').each( function () {
        var title = $('#serverlist thead th').eq( $(this).index() ).text();
        // 让第一列不显示在表尾
        if ($(this).index() == 0){
            $(this).html( '<input type="text" placeholder="Search '+title+'" />' );
        }
        else{
            $(this).html( '<input type="text" placeholder="Search '+title+'" />' );
        }
    } );

    // 表格
    table = $('#serverlist').DataTable({
        "pagingType":   "full_numbers",
        // "columnDefs":[
        //      {
        //        "targets": [ 2,5,10,11,12,13,14,15,16,17 ],
        //        "visible": false,
        //        "searchable": false
        //      },
        // ],
        "lengthMenu": [[15, 50, 100, -1], [15, 50, 100, "All"]],
        "autoWidth": true,
        dom: 'lfBrtip',
        buttons: [
            {
                extend: 'excel',
                text: '导出当前页',
                exportOptions: {
                    modifier: {
                        page: 'current'
                    }
                }
            },
            {
                extend: 'excel',
                text: '导出所有页',
                exportOptions: {
                    modifier: {
                        page: 'current'
                    }
                }
            }

        ],
        "scrollX": true,
        "language": {
            "sProcessing":"处理中...",
            "sLengthMenu":"显示_MENU_项结果",
            "sZeroRecords":"没有匹配结果",
            "sInfo":"显示第_START_至_END_项结果，共_TOTAL_项",
            "sInfoEmpty":"显示第0至0项结果，共0项",
            "sInfoFiltered":"(由_MAX_项结果过滤)",
            "sInfoPostFix":"",
            "sSearch":"搜索:",
            "sUrl":"",
            "sEmptyTable":"表中数据为空",
            "sLoadingRecords":"载入中...",
            "sInfoThousands":",",
            "oPaginate":{
                "sFirst":"首页",
                "sPrevious":"上页",
                "sNext":"下页",
                "sLast":"末页"
            },
            "oAria":{
                "sSortAscending":":以升序排列此列","sSortDescending":":以降序排列此列"
            }
        },
        initComplete: function () {//列筛选
             var api = this.api();
             api.columns().indexes().flatten().each(function (i) {
                 if (i != 0 && i != 18) {//删除第一列与第二列的筛选框
                     var column = api.column(i);
                     var $span = $('<span class="addselect">▾</span>').appendTo($(column.header()))
                     var select = $('<select><option value="">All</option></select>')
                             .appendTo($(column.header()))
                             .on('click', function (evt) {
                                 evt.stopPropagation();
                                 var val = $.fn.dataTable.util.escapeRegex(
                                         $(this).val()
                                 );
                                 column
                                         .search(val ? '^' + val + '$' : '', true, false)
                                         .draw();
                             });
                     column.data().unique().sort().each(function (d, j) {
                         function delHtmlTag(str) {
                             return str.replace(/<[^>]+>/g, "");//去掉html标签
                         }

                         d = delHtmlTag(d)
                         select.append('<option value="' + d + '">' + d + '</option>')
                         $span.append(select)
                     });
                 }
             });
        },
    });
    //选择行
    $('#serverlist tbody').on( 'click', 'tr', function () {
        if ( $(this).hasClass('selected') ) {
            $(this).removeClass('selected');
        }
        else {
            table.$('tr.selected').removeClass('selected');
            $(this).addClass('selected');
        }
    });
    // 表格角搜索
    table.columns().eq( 0 ).each( function ( colIdx ) {
        $( 'input', table.column( colIdx ).footer() ).on( 'keyup change', function () {
            table
                .column( colIdx )
                .search( this.value )
                .draw();
        } );
    });
    //显示隐藏列
    $('a.toggle-vis').on( 'click', function (e) {
        e.preventDefault();
        // Get the column API object
        var column = table.column( $(this).attr('data-column') );
        // Toggle the visibility
        column.visible( ! column.visible() );
        backgroundcolor = $(this).parent('li').css('background-color')
        console.log(backgroundcolor);
        if ( backgroundcolor == "rgb(255, 255, 0)" ){
            $(this).parent('li').css('background-color','white')
        }
        else{
            $(this).parent('li').css('background-color','yellow')
        }
    });
    //$('.download').click(function(e){
    $(document).on('click', '.download', function() {
        server_ipaddr = $(this).parent().parent().find('td').eq(2).text();
        server_dir = $(this).parent().parent().find('td').eq(3).text();
        window.open('/filemanager/'+server_ipaddr+'/'+server_dir+'/');
    });

// 执行mysql并填充表格
function exec_mysql(mysql_id,cmdline,select_db){
        // 表格数据源
        var ajax_data = [];
        // 表头数据
        var columns = []
        $.post("/database/get_tables/"+mysql_id+"/",{"cmdline":cmdline,"db":select_db},function(data,status){
            $("#mysql_result").append(data);
            $("#mysql_result").append("==========================================================================================\n");
            mysql_data = data.split('\n');
            $("#mysql_head").text("");
            for (index in mysql_data) {
                //$("#mysql_body").append("<tr></tr>")
                data = mysql_data[index].split("\t");
                if (data[0] == ""){
                    continue;
                }
                if (index == 0){
                    for (dex in data){
                         columns.push({"title":data[dex]})
                         $("#mysql_head").append("<th>" + data[dex]  +"</th>");
                    }
                }
                else{
                    ajax_data.push(data);
                }
            }
            if ( columns.length == 0 ){
                columns.push({"title": cmdline});
                ajax_data.push(["没有查找到数据"]);
            }
            var mysql_table = $('#mysql_table').DataTable();
            mysql_table.destroy();
            $('#mysql_table').empty()
            var mysql_table = $('#mysql_table').DataTable({
               "lengthMenu": [[10,20,50,100,-1], [ "10","20","50","100","All"]],
               "data": ajax_data,
               "columns": columns,
               "destroy": true,
               "scrollX": true,
               "language": {
                   "sProcessing":"处理中...",
                   "sLengthMenu":"显示_MENU_项结果",
                   "sZeroRecords":"没有匹配结果",
                   "sInfo":"显示第_START_至_END_项结果，共_TOTAL_项",
                   "sInfoEmpty":"显示第0至0项结果，共0项",
                   "sInfoFiltered":"(由_MAX_项结果过滤)",
                   "sInfoPostFix":"",
                   "sSearch":"搜索:",
                   "sUrl":"",
                   "sEmptyTable":"表中数据为空",
                   "sLoadingRecords":"载入中...",
                   "sInfoThousands":",",
                   "oPaginate":{
                       "sFirst":"首页",
                       "sPrevious":"上页",
                       "sNext":"下页",
                       "sLast":"末页"
                   },
                   "oAria":{
                       "sSortAscending":":以升序排列此列","sSortDescending":":以降序排列此列"
                   },
               },

            });
        });
}

    $("#mysql_result").hide();
    $("#show_mysql_result").click(function(){
        $("#mysql_result").toggle();
    });
    $(document).on('click', '.mysql', function() {
        info = $("thead").children("tr").eq(0).children("td").text();
        mysql_id = $(this).parent().parent().children(".database_ip").attr('id');
        mysql_ip = $(this).parent().parent().children(".database_ip").text();
        mysql_port = $(this).parent().parent().children(".database_port").text();
        mysql_database = $(this).parent().parent().children(".database_name").text();
        $('#mysql_ip').text(mysql_ip);
        $('#mysql_port').text(mysql_port);
        $('#mysql_database').text(mysql_database);
        $('#mysql').modal();
        $("#databases").text('')
        $("#databases").append('<option value="' + mysql_database + '">' + mysql_database + '</option>');
        exec_mysql(mysql_id,"show tables",mysql_database);
    });
    $("#sub_cmdline").submit(function(e){
        e.preventDefault();
//        // 表格数据源
//        var ajax_data = [];
//        // 表头数据
//        var columns = []
        select_db = $("#databases option:selected").text();
        cmdline = $("#cmdline").val();
        exec_mysql(mysql_id,cmdline,select_db);
    });
//    $('#getserverlist').click( function () {
//        $.get('/getserverlist/?a=1',function(data,status){
//             alert(data);
//        });
//    });
    // 设置导出按钮的样式
    $('.buttons-html5').eq(0).addClass('btn btn-info btn-xs');
    $('.buttons-html5').eq(1).addClass('btn btn-danger btn-xs');
    $('.buttons-html5').removeClass('dt-button');
    $('.dt-buttons').css('float','right');

    // 获取配置文件
    $(document).on('click', '.config', function() {
        $('.getconfigprogress').show();
        serverid = $(this).parent().parent().children(".serverid").text();
        $.post('/getconfig/',{serverid:serverid},function(data,status){
             $('.getconfigprogress').hide();
             $('#getconfig').modal();
             $('#getconfig_div').html(data);
             console.log(status);
        });
    });
});

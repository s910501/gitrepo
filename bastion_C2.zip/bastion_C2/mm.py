from celery import Celery
import time


def my_monitor(app):
    state = app.events.State()

    def on_event(event):
        time.sleep(20)
        print("EVENT HAPPENED: ", event)

    def on_event_r(event):
        print("EVENT HAPPENED_r: ", event)

    def announce_failed_tasks(event):
        state.event(event)
        # task name is sent only with -received event, and state
        # will keep track of this for us.
        task = state.tasks.get(event['uuid'])

        print('TASK FAILED: %s[%s] %s' % (
            task.name, task.uuid, task.info(),))

    with app.connection() as connection:
        recv = app.events.Receiver(connection, handlers={
                'task-failed': announce_failed_tasks,
                'task-succeeded' : on_event,
                'task-received' : on_event_r,
                '*': state.event,
        })
        recv.capture(limit=None, timeout=None, wakeup=True)

if __name__ == '__main__':
    app = Celery(broker='redis://:ehl4u9WmPrxcFpLiJxLLMwNrPxQCQCAQ@127.0.0.1:6379/0')
    my_monitor(app)

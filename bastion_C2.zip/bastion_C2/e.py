import salt.client

local = salt.client.LocalClient()
#p = local.cmd('txvm_bmlh_sgame01.hoolai.com', 'grains.set', [ 'update_dir', ['/data/server_3/','/data/server_7/','/data/server_8/','/data/server_9/'], "force=True"])
#p = local.cmd('txvm_bmlh_sgame01.hoolai.com', 'grains.set', [ 'update_dir', ['/data/server_3/','/data/server_7/','/data/server_8/','/data/server_9/'], "force=True"])
#print(p)
pp = local.cmd_async('txvm_bmlh_sgame01.hoolai.com,txvm_bmlh_web01.hoolai.com', 'state.sls', ["update.update_file", "pillar={'operation_user':'shenzm'}"], ret='mysql1', tgt_type='list')
print(pp)

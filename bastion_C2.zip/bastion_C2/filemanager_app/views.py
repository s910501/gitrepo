from django.conf import settings
from django.shortcuts import render
from django.shortcuts import render_to_response
from utils.utils import decrypt, encrypt
import json
from django.http import HttpResponse
import shutil
import os
import io
from bastion.settings import PROJECTDIR
import paramiko
from . import filemanager
from django.db.models import Q
from django.contrib.auth.decorators import login_required
#from filemanager import FileManager
from utils import sshconn
from websshapp.models import MachineList, Credential
from django.core.exceptions import ObjectDoesNotExist
from utils.sshconn import http_proxy_tunnel_connect
from utils import set_redis_password
from django.contrib.auth import get_user_model
User = get_user_model()


DIR_ROOT = '/'
fm = filemanager.FileManager(DIR_ROOT, False)
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
import logging
logger = logging.getLogger('django')


def connect(request):
    ipaddr = request.path.split('/')[-4]
    credential = request.path.split('/')[-3]
    #print(request.path.split('/'))
    # if ipaddr == 'localhost':
    #print(request.body.decode('utf-8'))
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

    data = MachineList.objects.get(Q(ip=ipaddr) | Q(internetip=ipaddr))
    user = User.objects.get(username=request.user.username)
    credential = Credential.objects.get(id=int(credential), addby=user)
    port = credential.port
    method = credential.method
    password = decrypt(credential.password)
    username = credential.username
    proxy = credential.proxy
    proxyserverip = credential.proxyserverip
    proxyport = credential.proxyport
    key = credential.key
    sock = ''
    if proxy:
        sock = http_proxy_tunnel_connect(proxy=(proxyserverip, proxyport), target=(ipaddr, port), timeout=30)
    if method == 'password' and not proxy:
        ssh.connect(ipaddr, port=port, username=username, password=password, timeout=20)
    elif method == 'password' and proxy:
        from bastion.asgi import channel_layer
        redis_instance = channel_layer._connection_list[0]
        password = redis_instance.get('OPENPASSWORD');
        ## 无密码时获取密码，有密码时直接连接，出错时再获取密码连接
        if not password:
            password = set_redis_password(redis_instance)
        ssh.connect(ipaddr, sock=sock, port=port, username=username, password=password, timeout=30)
    else:
        # pkey = paramiko.RSAKey.from_private_key_file(key, password=password)
        private_key_file = io.StringIO()
        private_key_file.write(key)
        private_key_file.seek(0)
        pkey = paramiko.RSAKey.from_private_key(private_key_file, password=password)

        ssh.connect(ipaddr, port=port, username=username, pkey=pkey, timeout=10)
    print('ssh ok!')
    return ssh


@login_required
def index(request, ipaddr, credential,directory):
    logger.info(request.body.decode('utf-8') + ':' + request.user.username)
    permission = 'part'
    if ipaddr in settings.MANAGEMACHINE:
        permission ='all'
    if ipaddr == 'localhost':
        permission = 'upload'
    print(dir)
    return render(request, 'filemanager.html',{'permission':permission})


@login_required
def list_(request):
    logger.info(request.body.decode('utf-8') + ':' + request.user.username)
    dir = request.path.split('/')[-2]
    ipaddr = request.path.split('/')[-4]
    ## 因为open平台用的是10网段所以有这个设计
    pythonexec = '/usr/local/python/bin/python'
    pythonexec = '/usr/bin/python'

    if not ipaddr.startswith('10'):
        pythonexec = '/usr/bin/python'
    if ipaddr in settings.MANAGEMACHINE and dir == 'null':
        fm = filemanager.FileManager('/', False)
        return HttpResponse(json.dumps(fm.list(json.loads(request.body.decode('utf-8')))))
    if ipaddr == 'localhost':
        fm = filemanager.FileManager('/data/www/shell/', False)
        return HttpResponse(json.dumps(fm.list(json.loads(request.body.decode('utf-8')))))
    else:
        ssh = connect(request)
        sftp = paramiko.SFTPClient.from_transport(ssh.get_transport())
        sftp.put('/data/bastion/filemanager_app/send.py', '/tmp/send_exec.py')

        root_dir = json.loads(request.body.decode('utf-8'))['path']
        if dir == 'null':
            list_dir = root_dir
        else:
            list_dir = PROJECTDIR + dir + root_dir
        stdin, stdout, stderr = ssh.exec_command('chmod +x /tmp/send_exec.py;'+ pythonexec +' /tmp/send_exec.py ' + list_dir)
        # print(stdin.read(), 'stdin')
        # print(stdout.read(), 'stdout')
        # print(stderr.read(), 'stderr')
        stdout_result, stderr_result = stdout.read(), stderr.read()
        result=''
        if stderr_result.decode():
            result = stderr_result.decode('utf-8')
        else:
            result = stdout_result.decode('utf-8')
        sftp.close()
        ssh.close()
        return HttpResponse(json.dumps(json.loads(result)))
        # return HttpResponse(json.dumps(fm.list(json.loads(request.body.decode('utf-8')))))


@login_required
def rename(request):
    logger.info(request.body.decode('utf-8') + ':' + request.user.username)
    return HttpResponse(json.dumps(fm.rename(json.loads(request.body.decode('utf-8')))))


@login_required
def copy(request):
    logger.info(request.body.decode('utf-8') + ':' + request.user.username)
    return HttpResponse(json.dumps(fm.copy(json.loads(request.body.decode('utf-8')))))


@login_required
def remove(request):
    ipaddr = request.path.split('/')[-3]
    if ipaddr == 'localhost':
        fm = filemanager.FileManager('/data/www/shell/', False)
    logger.info(request.body.decode('utf-8') + ':' + request.user.username)
    return HttpResponse(json.dumps(fm.remove(json.loads(request.body.decode('utf-8')))))


@login_required
def edit(request):
    logger.info(request.body.decode('utf-8') + ':' + request.user.username)
    return HttpResponse(json.dumps(fm.edit(json.loads(request.body.decode('utf-8')))))


@login_required
def createFolder(request):
    logger.info(request.body.decode('utf-8') + ':' + request.user.username)
    return HttpResponse(json.dumps(fm.createFolder(json.loads(request.body.decode('utf-8')))))


@login_required
def changePermissions(request):
    logger.info(request.body.decode('utf-8') + ':' + request.user.username)
    return HttpResponse(json.dumps(fm.changePermissions(json.loads(request.body.decode('utf-8')))))


@login_required
def compress(request):
    logger.info(request.body.decode('utf-8') + ':' + request.user.username)
    return HttpResponse(json.dumps(fm.compress(json.loads(request.body.decode('utf-8')))))


@login_required
def downloadMultiple(request):
    filenames = json.dumps(dict(request.GET.lists())['items[]'])
    logger.info('download multiple files: {0}, user: {1}'.format(filenames, request.user.username))
    ret = fm.downloadMultiple(request.GET, HttpResponse)
    os.umask(ret[1])
    shutil.rmtree(ret[2], ignore_errors=True)
    return ret[0]


@login_required
def move(request):
    logger.info(request.body.decode('utf-8') + ':' + request.user.username)
    return HttpResponse(json.dumps(fm.move(json.loads(request.body.decode('utf-8')))))


@login_required
def getContent(request):
    logger.info(request.body.decode('utf-8') + ':' + request.user.username)
    return HttpResponse(json.dumps(fm.getContent(json.loads(request.body.decode('utf-8')))))


@login_required
def extract(request):
    logger.info(request.body.decode('utf-8') + ':' + request.user.username)
    return HttpResponse(json.dumps(fm.extract(json.loads(request.body.decode('utf-8')))))


@login_required
def download(request):
    logger.info(request.GET['path'] + ':' + request.user.username)
    dir = request.path.split('/')[-2]
    ipaddr = request.path.split('/')[-4]
    DOWNLOADDIR = 'data/bastion/download/'
    if ipaddr in settings.MANAGEMACHINE and dir == 'null':
        fm = filemanager.FileManager('/data/www/shell/', False)
        return fm.download(request.GET['path'], HttpResponse)
    if ipaddr == 'localhost':
        fm = filemanager.FileManager('/data/www/shell/', False)
        return fm.download(request.GET['path'], HttpResponse)
    else:
        filename = request.GET['path'].split('/')[-1]
        ssh = connect(request)
        sftp = paramiko.SFTPClient.from_transport(ssh.get_transport())
        if dir == 'null':
            download_dir = request.GET['path']
        else:
            download_dir = PROJECTDIR + dir + request.GET['path']
        sftp.get(download_dir, DIR_ROOT+DOWNLOADDIR+filename)
        print('download ok!')
        sftp.close()
        ssh.close()
        fm = filemanager.FileManager(DIR_ROOT+DOWNLOADDIR, False)
        return fm.download('/'+filename, HttpResponse)


@login_required
def upload(request):
    ipaddr = request.path.split('/')[-3]
    if ipaddr == 'localhost':
        fm = filemanager.FileManager('/data/www/shell/', False)
    for x in request.FILES:
        filename = request.FILES.get(x).name
        logger.info('upload filename: {0}, upload path: {1}, user: {2}'.format(filename, request.POST['destination'], request.user.username))
    return HttpResponse(json.dumps(fm.upload(request.FILES, request.POST['destination'])))
